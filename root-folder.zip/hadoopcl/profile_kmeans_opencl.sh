#CPU_GROUP_LIST="12 24"
#GPU_GROUP_LIST="24 36"
#CPU_THREAD_LIST="64 128"
#GPU_THREAD_LIST="128 256"
CPU_GROUP_LIST="8"
GPU_GROUP_LIST="36"
CPU_THREAD_LIST="196"
GPU_THREAD_LIST="256"

buffer=1048576
mapper=8
hdfs_chunk_size=268435456

NODES=`cat $PBS_NODEFILE | sort | uniq`

./KILL.sh
sleep 30

for cpu_group in ${CPU_GROUP_LIST}; do
    for gpu_group in ${GPU_GROUP_LIST}; do
        for cpu_thread in ${CPU_THREAD_LIST}; do 
            for gpu_thread in ${GPU_THREAD_LIST}; do

# number_of_mappers
# number_of_reducers
# 
# opencl.mapper.groups.gpu
# opencl.mapper.groups.cpu
# opencl.mapper.threadsPerGroup.gpu
# opencl.mapper.threadsPerGroup.cpu
# opencl.mapper.buffers.gpu
# opencl.mapper.buffers.cpu
# opencl.mapper.bufferSize.gpu
# opencl.mapper.bufferSize.cpu
# 
# opencl.reducer.groups.gpu
# opencl.reducer.groups.cpu
# opencl.reducer.threadsPerGroup.gpu
# opencl.reducer.threadsPerGroup.cpu
# opencl.reducer.buffers.gpu
# opencl.reducer.buffers.cpu
# opencl.reducer.bufferSize.gpu
# opencl.reducer.bufferSize.cpu
#
# hdfs chunk size

                echo DOING ${mapper} ${hdfs_chunk_size} ${cpu_group} ${cpu_thread}
                ./startup.sh ${mapper} 1 ${gpu_group} ${cpu_group} ${gpu_thread} ${cpu_thread} 3 3 ${buffer} ${buffer} ${gpu_group} ${cpu_group} ${gpu_thread} ${cpu_thread} 3 3 ${buffer} ${buffer} ${hdfs_chunk_size}
                sleep 60 
                bin/hadoop fs -put /scratch/jmg3/kmeans.input kmeans.input
                ~/profile-scripts/profile.sh kmeans.opencl &
                PROF_PID=$!
                time bin/hadoop jar KMeansOpenCLVersion.jar KMeansOpenCLVersion kmeans.input kmeans.output
                kill -9 ${PROF_PID}
                #bin/hadoop fs -get kmeans.output /scratch/jmg3/kmeans.output/
#                for n in ${NODES}; do
#                    ssh -o ConnectTimeout=2 ${n} "grep -n -R 'DIAGNOSTICS' /tmp/${PBS_JOBID}/* > /scratch/jmg3/diagnostics.kmeans.opencl.${PBS_JOBID}.${mapper}.${cpu_group}.${gpu_group}.${cpu_thread}.${gpu_thread}.${buffer}.${hdfs_chunk_size}.${n}"
#                    #ssh -o ConnectTimeout=2 ${n} "cp /tmp/${PBS_JOBID}/hadoop-jmg3/mapred/local /scratch/jmg3/folder.${n} -rf" 
#                done
                ./KILL.sh
                sleep 10
            done
        done
    done
done

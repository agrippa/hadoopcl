#SLOTS="1 2 4 8 12 16"
SLOTS="12"


NODES=`cat $PBS_NODEFILE | sort | uniq`

./KILL.sh

for s in ${SLOTS}; do 
    ./startup.sh ${s} 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 67108864
    sleep 30
    bin/hadoop fs -put /scratch/jmg3/kmeans.input kmeans.input
    echo DOING ${s}
    ~/profile-scripts/profile.sh kmeans.java &
    PROF_PID=$!
    time bin/hadoop jar KMeansJavaVersion.jar KMeansJavaVersion kmeans.input kmeans.output
    kill -9 ${PROF_PID}
#    bin/hadoop fs -get kmeans.output /scratch/jmg3/kmeans.output/
#    for n in ${NODES}; do
#        ssh -o ConnectTimeout=2 ${n} "grep -n -R 'DIAGNOSTICS' /tmp/${PBS_JOBID}/* > /scratch/jmg3/diagnostics.kmeans.java.${PBS_JOBID}.${s}.${n}"
#    done
#    ./KILL.sh
done

import os
import sys

if len(sys.argv) < 3:
    print 'usage: python plotData.py filename device filter'
    sys.exit()

fp = open(sys.argv[1], 'r')
device = int(sys.argv[2])
if len(sys.argv) == 4:
    filter = sys.argv[3]
else:
    filter = None

X = [ ]
Y = [ ]

lastLine = None

for line in fp:
    tokens = line.split()
    thisDevice = int(tokens[1])
    if thisDevice == device:
        useLine = True
        if filter != None and line.find(filter) == -1:
            useLine = False
        if useLine:
            lastLine = line
            rate = float(tokens[2])
            occ = float(tokens[4+device])
            X.append(occ)
            Y.append(rate)

sys.stdout.write('X = [ '+str(X[0]))
for i in range(1, len(X)):
    sys.stdout.write(', '+str(X[i]))
sys.stdout.write(']\n')
sys.stdout.write('Y = [ '+str(Y[0]))
for i in range(1, len(Y)):
    sys.stdout.write(', '+str(Y[i]))
sys.stdout.write(']\n')

print lastLine

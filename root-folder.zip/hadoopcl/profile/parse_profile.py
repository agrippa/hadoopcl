import sys
import os

if len(sys.argv) != 2:
    print 'usage: python parse_profile.py filename'
    sys.exit()


fp = open(sys.argv[1], 'r')

line = fp.readline()
line = fp.readline()
while len(line) > 0:
    tokens = line.split()
    timeStr = tokens[1]

    line = fp.readline()
    grouped_lines = [ ]
    while len(line) > 0 and line.find('GPU') == -1:
        grouped_lines.append(line)
        line = fp.readline()

    sumProc = 0.0
    sumMem = 0.0
    gpu0 = 0.0
    gpu1 = 0.0

    line = fp.readline()
    if len(line) == 0:
        break;
    tokens = line.split()
    gpu0 = float(tokens[0])
    gpu1 = float(tokens[1])
    line = fp.readline()

    for l in grouped_lines:
        tokens = l.split()
        sumProc += float(tokens[0])
        sumMem += float(tokens[1])

    print timeStr+' '+str(sumProc)+' '+str(sumMem)+' '+str(gpu0)+' '+str(gpu1)
        

    

. check-base
ssh-all "rm -rf /tmp/*"

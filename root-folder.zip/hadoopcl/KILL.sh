. check-base
ssh-all "killall -9 java"
ssh-all "ps aux | grep java"

#!/bin/bash

. s-header

cfg="sed-cfg"
WHOISVARYING="START" 

INPUT="1.3G-128M-rnd"
OUTPUT="1.3G-128M-out"


RUN_ST=100
RUN_END=122
DFS_REPLICATION=3 

#Hadoop parameters
HTTPCOPIERS=5
NRMAPSLOTS=2
NRREDUCESLOTS=2
NRREDUCERS=$(($NRNODES*1)) 
NRDATANODEHANDLERS=3
NRHDFSXCEIVERS=256
EXPID=0;
HTTPATMAP=40;
NR_NN_HANDLERS=10; 
#BLOCK_SIZE=134217728
BLOCK_SIZE=67108864
#BLOCK_SIZE=268435456
SCHEDULER='FairScheduler'
CONCURRENT_JOBS=1

for i in `seq 1 7`; do ((EXPID=$EXPID*10+($RANDOM%9+1))); done
EXPECTED_PROCESSES=$((2*$NRNODES));
CRT_DATE=`date +'%m.%d..%H.%M.%S'`
EXPID="${EXPID}R-$CRT_DATE"


> $CHECKER
> $EXPERIMENT_LOG
export HADOOP_SLAVE_SLEEP=0.2


echo "Variables set.........."

update-configuration-files() {

echo "Deleting old config files................."


> $cfg
echo "s/threads<\/name><value>[0-9]*<\/value>/threads<\/name><value>$HTTPATMAP<\/value>/g" >> $cfg
echo "s/copies<\/name><value>[0-9]*<\/value>/copies<\/name><value>$HTTPCOPIERS<\/value>/g" >> $cfg
echo "s/map.tasks.maximum<\/name><value>[0-9]*<\/value>/map.tasks.maximum<\/name><value>$NRMAPSLOTS<\/value>/g" >> $cfg
echo "s/reduce.tasks.maximum<\/name><value>[0-9]*<\/value>/reduce.tasks.maximum<\/name><value>$NRREDUCESLOTS<\/value>/g" >> $cfg
	
sed -f $cfg $cfg_path/mapred-site.xml > $cfg_path/mapred-site.xml2
rm $cfg_path/mapred-site.xml
mv $cfg_path/mapred-site.xml2 $cfg_path/mapred-site.xml

echo "s/datanode.handler.count<\/name><value>[0-9]*<\/value>/datanode.handler.count<\/name><value>$NRDATANODEHANDLERS<\/value>/g" > $cfg
echo "s/namenode.handler.count<\/name><value>[0-9]*<\/value>/namenode.handler.count<\/name><value>$NR_NN_HANDLERS<\/value>/g" >> $cfg
echo "s/xcievers<\/name><value>[0-9]*<\/value>/xcievers<\/name><value>$NRHDFSXCEIVERS<\/value>/g" >> $cfg
echo "s/dfs.replication<\/name><value>[0-9]*<\/value>/dfs.replication<\/name><value>$DFS_REPLICATION<\/value>/g" >> $cfg
echo "s/dfs.block.size<\/name><value>[0-9]*<\/value>/dfs.block.size<\/name><value>$BLOCK_SIZE<\/value>/g" >> $cfg

sed -f $cfg $cfg_path/hdfs-site.xml > $cfg_path/hdfs-site.xml2
rm $cfg_path/hdfs-site.xml
mv $cfg_path/hdfs-site.xml2 $cfg_path/hdfs-site.xml



#delete the log files in the log directory on all nodes
echo "Delete old log files from the directory where new logs are created............."
rm -fr $log_path/*
}



sleep_print() {
	for i in `seq 1 $1`
	do 
		sleep 1 
		echo -n " $i/$1 "
	done 
	echo 
}





start-hadoop-with-kill-guard () {

	update-configuration-files	

echo "Attempting a correct start"
#check if the start was successful
problem=1

while [ $problem -eq 1 ]
do	

	$mpath/bin/stop-all.sh
	$mpath/bin/start-all.sh
	problem=0;
 	tr=0; 

 
	 nrproc_local=`ps -ef | egrep 'JobTracker|NameNode' | grep -v egrep | wc -l` 
 	 if [ $nrproc_local -ne 3 ] 
	 then 
		 problem=1; 
		 echo "$MASTER did not start all 3 processes. Started $nrproc_local 		`date`"  | tee -a $CHECKER;
		 echo "---------------------------------------"  
		 ps -ef | egrep 'JobTracker|Namenode' | grep -v egrep
		 echo "---------------------------------------"  
	 fi


	for i in $COMP_NODES 
 	do 
		 nrp=`ssh $i ps -ef | egrep 'DataNode|TaskTracker' | wc -l`; 
		 if [ $nrp -ne 2 ]; then echo "$i did not start all. Started $nrp		`date`" | tee -a $CHECKER; problem=1;fi
	done

done    

echo "Success `date`" | tee -a $CHECKER
echo "Log path is: $log_path"

sleep_print 1
#grep returns 0 when it matches something
while [ `bin/hadoop dfs -rmr $OUTPUT* 2>&1 | grep safe >/dev/null;echo $?` -eq 0 ] ; do echo "Namenode is in Safe Mode"; sleep 2; done
echo "Deleting $OUTPUT from guard"
}


experiment () {

	IN_SIZE=`echo $INPUT | grep -o '[0-9.]*G'`
	DIRNAME="$EXPID-RUN$run-$allrun-$MASTER-VARYXY-$WHOISVARYING-N$NRNODES-SL$NRMAPSLOTS-$NRREDUCESLOTS-RED$NRREDUCERS-R$DFS_REPLICATION-SZ$IN_SIZE-CJ$CONCURRENT_JOBS-S${SCHEDULER:0:1}"
	echo $DIRNAME >> $CHECKER	
	echo | tee -a $CHECKER

	#create a directory on the master for the logs of this run 
	date
	dirsuffix=$DIRNAME-`date|awk '{print $3,$4}' | tr " " "-"`
	newdir=$exppath/$dirsuffix
 	mkdir -p $newdir/TASK_OUTPUT
	echo;echo;echo "--------------RUNNING $newdir-----------------------------------------"
	echo -n $dirsuffix >> $EXPERIMENT_LOG

	echo "[Safe mode guard] Waiting for namenode to exit safemode"
	#make sure NN is done with safe mode.
	#jobtracker.info is the first JT cfg file replicated at beginning and this occurs after safe mode is turned off
	#then 2.job.jar 3.job.split. 4.job.splitmetainfo  5. job.xml  6. job.info   7.jobToken.
	ctr3=0
	while [ `cat $log_path/hadoop-$USER-namenode-$MASTERFULL.log | grep jobtracker.info | grep create| wc -l` -eq 0 ]; do 
		sleep 1; ctr3=$(($ctr3+1)); echo -n "$ctr3 "; done 
	echo;echo "[Safe mode guard] After ${ctr3}s jobtracker.info the first of 7 initial cfg files was written at `date`"


	#giving max 15 minutes for all DNs to register otherwise fail
	echo; echo "[Register all DNs] Waiting for all DataNodes to register"
	ctr3=0	
	while [ `cat $log_path/hadoop-$USER-namenode-$MASTERFULL.log | grep registerDatanode | wc -l` -lt $NRNODES ]; 
	do 
		sleep 1; ctr3=$(($ctr3+1)); echo -n "$ctr3 "; 
		if [ $ctr3 -gt 900 ] 
		then
			return
		fi
	done 
	echo; echo "[Register all DNs] After another ${ctr3}s all DataNodes have registered at `date`"

	#giving max 15 minutes for all TTs to register otherwise fail
	echo; echo "[Register all TTs] Waiting for all TaskTrackers to register"
	ctr3=0	
	while [ `cat $log_path/hadoop-$USER-jobtracker-$MASTERFULL.log | grep 'Adding a new node' | wc -l` -lt $NRNODES ]; 
	do 
		sleep 1; ctr3=$(($ctr3+1)); echo -n "$ctr3 "; 
		if [ $ctr3 -gt 900 ] 
		then
			return
		fi
	done 
	echo; echo "[Register all TTs] After another ${ctr3}s all TaskTrackers have registered at `date`"

	shutdowns=0;	
	#for i in $COMP_NODES 
 	#do  
	nr_shutdown_text=`grep SHUTDOWN "$log_path/*.log"`
	nr_shutdown_lines=`grep SHUTDOWN "$log_path/*.log" | wc -l`
	if [ "$nr_shutdown_lines" -ne 0 ]
	then
		echo "There are SHUTDOWN events for node $i. Quitting experiment run" 
		echo $nr_shutdown_text
		echo 
		shutdowns=1
	fi

	reg_DN=`cat $log_path/hadoop-$USER-namenode-$MASTERFULL.log | grep registerDatanode | wc -l`		
	echo "reg_DN: $reg_DN"	
	reg_TT=`cat $log_path/hadoop-$USER-jobtracker-$MASTERFULL.log | grep 'Adding a new node' | wc -l`		
	echo "reg_TT: $reg_TT"


	if [ $shutdowns -ne 1 ]
        then	
		$mpath/bin/hdfs dfs -rmr $OUTPUT*
		echo "Deleting $OUTPUT from experiment `date`"
		#running 
		echo;echo "Submitting job `date`"
		
		conc_ctr=0
		while [ $conc_ctr -lt $CONCURRENT_JOBS ]
		do 
		bin/hadoop jar hadoop-examples-1.0.3.jar sort \
			-Ddfs.replication=$DFS_REPLICATION \
			-Dmapreduce.jobtracker.taskscheduler=$SCHEDULER \
			-r $NRREDUCERS $INPUT "$OUTPUT.$conc_ctr" 2>&1 | tee $log_path/output.log.$conc_ctr &

			pidArr[$conc_ctr]=$!
			conc_ctr=$(($conc_ctr+1))
		done


	
		conc_wait=0
		while [ $conc_wait -lt $CONCURRENT_JOBS ]
		do
			wait ${pidArr[$conc_wait]}	
			conc_wait=$(($conc_wait+1))
			echo "Done waiting for job $conc_wait"
		done	

		#prints either job runing time or killed at end of LOG
		# ! applies (or so I hope) to all until &&.    Prints killed if job took not found, grep returns 1 on failed match.  && continues after 0 is returned
		echo -n "     end: "    `date|awk '{print $3,$4}' | tr " " "-"`    "  "    `! cat $log_path/output*.log | grep 'job took' | grep -o '[0-9]*' && echo "Killed"`  | tee -a $EXPERIMENT_LOG
	 	echo "     regDN: $reg_DN" | tee -a $EXPERIMENT_LOG
		date
		echo "Job ended. Sleep for a while"

		sleep_print 1
	else
		echo "Returning from job prematurely. Shutdown events found"
	fi

	echo "Flushing caches.................."
	$mpath/bin/hdfs dfs -rmr $OUTPUT*
	echo "Output deleted `date`"

	chmod -R 777 $log_path/userlogs	
	rm -r $log_path/userlogs
	echo "After deleting userlogs `date`"
	mv $log_path/* $newdir
	job_name=`cat $newdir/hadoop-$USER-jobtracker-$MASTERFULL.log | grep Initializing | grep Progress | grep -o "job_[0-9]*_[0-9]*"`
	#if there are multiple jobs, how does this only take the first?
	echo "Name of finished job: ------------$job_name----------------"
	
	cp $mpath/s-exp-runner.sh $newdir 
	cp $EXPERIMENT_LOG $newdir
	cp $EXEC_OUT $newdir
	cp $cfg_path/slaves $newdir	

	for i in $COMP_NODES; do ssh $i "mv $log_path/*.log $newdir";done
	for i in $COMP_NODES; do ssh $i "mv $log_path/*.out $newdir";done

	echo "End of current run at `date`"
	echo
	echo
}


#start memory checks



 
allrun=1
for run in `seq $RUN_ST $RUN_END`
do
	#for DFS_REPLICATION in 1 2 3 4 5
	#do
		#for CONCURRENT_JOBS in 1 4
		#do
			WHOISVARYING="SOMENAME"
			start-hadoop-with-kill-guard
			experiment 
			allrun=$(($allrun+1))
	#	done
	#done	
done 


cp $EXEC_OUT          $exp_path/$EXEC_OUT-$EXPID 
cp $EXPERIMENT_LOG    $exp_path/$EXPERIMENT_LOG-$EXPID


echo "Everything done. exiting.                `date`" | tee -a $CHECKER
$mpath/bin/stop-all.sh
exit 


